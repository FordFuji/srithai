<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <?php require('inc_header.php'); $memberName="point"; ?>
</head>
<body>
    <?php require('inc_topmenu.php'); ?>

    <!---------- MEMBER ---------->
    <div class="content-padding foot-pad minH">
        <div class="container-fluid">
			<div class="wrap-pad">

                <div class="member-section">
                    <div class="row">
                        <?php require('inc_membermenu.php'); ?>

                        <!---------- MEMBER :: POINT ---------->
                        <div class="col-lg-9 col-md-12 col-12">
                            <div class="row">
                                <div class="col">
                                    <h4>คะแนนสะสม</h4>
                                </div>
                            </div>

                            <div class="row justify-content-center">
                                <div class="col-xl-7 col-lg-8 col-md-7 col-12">
                                    <div class="pointBox">
                                        <div class="pointBox-content">
                                            <div class="row">
                                                <div class="col">
                                                    <h5>ยอดคะแนนสะสม</h5>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col">
                                                    <div class="my-point">
                                                        <p><span>285</span>คะแนน</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>

                            <!---------- POINT :: INFO ---------->
                            <div class="row justify-content-center">
                                <div class="col-xl-10 col-lg-11 col-md-11 col-12">
                                <div class="headerTB d-none d-sm-block">
                                        <div class="row">
                                            <div class="col-4">วันที่ได้รับ</div>
                                            <div class="col-4">เลขที่คำสั่งซื้อ</div>
                                            <div class="col-4">คะแนน</div>
                                        </div>
                                    </div>
                                    <div class="bodyTB">
                                        <div class="bodyTB-sub">
                                            <div class="row">
                                                <div class="col-6 d-block d-sm-none">วันที่ได้รับ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <ul>
                                                            <li>10/01/2022</li>
                                                            <li>15:30</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">เลขที่คำสั่งซื้อ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>ST000456</p>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">คะแนน</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>+86</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bodyTB-sub">
                                            <div class="row">
                                                <div class="col-6 d-block d-sm-none">วันที่ได้รับ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <ul>
                                                            <li>22/12/2021</li>
                                                            <li>15:30</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">เลขที่คำสั่งซื้อ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>ST000402</p>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">คะแนน</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>+54</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bodyTB-sub">
                                            <div class="row">
                                                <div class="col-6 d-block d-sm-none">วันที่ได้รับ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <ul>
                                                            <li>17/11/2021</li>
                                                            <li>15:30</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">เลขที่คำสั่งซื้อ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>ST000387</p>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">คะแนน</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>-50</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bodyTB-sub">
                                            <div class="row">
                                                <div class="col-6 d-block d-sm-none">วันที่ได้รับ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <ul>
                                                            <li>23/09/2021</li>
                                                            <li>15:30</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">เลขที่คำสั่งซื้อ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>ST000355</p>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">คะแนน</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>+125</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="bodyTB-sub">
                                            <div class="row">
                                                <div class="col-6 d-block d-sm-none">วันที่ได้รับ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <ul>
                                                            <li>05/08/2021</li>
                                                            <li>15:30</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">เลขที่คำสั่งซื้อ</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>ST000288</p>
                                                    </div>
                                                </div>
                                                <div class="col-6 d-block d-sm-none">คะแนน</div>
                                                <div class="col-lg-4 col-md-4 col-6">
                                                    <div class="content-middle">
                                                        <p>+70</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    
    <?php require('inc_footer.php'); ?>

</body>
</html>